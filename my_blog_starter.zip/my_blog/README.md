# my_blog (Quarto + Hugo PaperMod Starter)

This is a ready-to-use starter: **Quarto produces content → Hugo (PaperMod) renders the site**.

## Quick Start

1. **Install** Quarto + Hugo (extended).
2. **Fetch the theme**:
   ```bash
   bash setup_theme.sh
   ```
3. **Render content**:
   ```bash
   cd analysis
   quarto render
   cd ..
   ```
4. **Preview**:
   ```bash
   hugo server -D
   ```
5. **Push to GitHub** and enable Pages. CI will auto-build and publish.

## Notes
- Write new posts under `analysis/posts/<slug>/<slug>.qmd`, then `quarto render`.
- Content appears in `content/posts/<slug>/` for Hugo to consume.
