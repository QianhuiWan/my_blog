#!/usr/bin/env bash
set -e
# Initialize git if needed
if [ ! -d .git ]; then
  git init
fi
# Add PaperMod via submodule (safe if already added)
if ! git config --file .gitmodules --get-regexp '^submodule\.themes/PaperMod\.url' >/dev/null 2>&1; then
  git submodule add https://github.com/adityatelange/hugo-PaperMod themes/PaperMod || true
fi
git submodule update --init --recursive
echo "PaperMod theme is ready under themes/PaperMod"
